"""
desc: 神经网络python实现
"""
